# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
"""Utilities for parsing and generating stub files for TVM FFI."""

from __future__ import annotations

import dataclasses
import difflib
import os
import traceback
from collections.abc import Collection, Generator, Iterable
from pathlib import Path
from typing import Callable

from . import consts as C


def syntax_for(path: Path) -> C.MarkerSyntax:
    """Pick the comment-marker syntax for a file based on its extension."""
    return C.SYNTAX_BY_EXT.get(path.suffix.lower(), C.PYTHON_SYNTAX)


@dataclasses.dataclass
class CodeBlock:
    """A block of code to be generated in a stub file."""

    kind: C.STUB_BLOCK_KINDS
    param: str | tuple[str, ...]
    lineno_start: int
    lineno_end: int | None
    lines: list[str]

    def __post_init__(self) -> None:
        """Validate the code block after initialization."""
        assert self.kind in {
            "global",
            "object",
            "import-section",
            "directive",
            "export",
            "__all__",
            None,
        }

    @property
    def indent(self) -> int:
        """Calculate the indentation level of the block based on the first line."""
        if not self.lines:
            return 0
        first_line = self.lines[0]
        return len(first_line) - len(first_line.lstrip(" "))

    @staticmethod
    def from_begin_line(lineo: int, line: str, syntax: C.MarkerSyntax) -> CodeBlock:
        """Parse a line to create a CodeBlock if it contains a stub begin marker."""
        if not line.startswith(syntax.begin):
            # One-line directive `<comment> tvm-ffi-stubgen(<name>): <payload>`. The payload is
            # kept verbatim for whoever consumes the name: the pipeline or the generator.
            name, sep, payload = line[len(syntax.prefix) :].partition("):")
            if not sep or not name or not name.replace("-", "_").isidentifier():
                raise ValueError(f"Unknown stub type at line {lineo}: {line}")
            return CodeBlock(
                kind="directive",
                param=(name, payload.strip()),
                lineno_start=lineo,
                lineno_end=lineo,
                lines=[],
            )
        assert line.startswith(syntax.begin)
        param: str | tuple[str, ...]
        stub = line[len(syntax.begin) :].strip()
        if stub.startswith("global/"):
            kind = "global"
            param = stub[len("global/") :].strip()
            param = tuple(param.split("@")) if "@" in param else (param, "")
        elif stub.startswith("object/"):
            kind = "object"
            param = stub[len("object/") :].strip()
        elif stub == "import-section":
            kind = "import-section"
            param = ""
        elif stub.startswith("export/"):
            kind = "export"
            param = stub[len("export/") :].strip()
        elif stub == "__all__":
            kind = "__all__"
            param = ""
        else:
            raise ValueError(f"Unknown stub type `{stub}` at line {lineo}")
        return CodeBlock(
            kind=kind,
            param=param,
            lineno_start=lineo,
            lineno_end=None,
            lines=[],
        )


@dataclasses.dataclass
class FileInfo:
    """Information about a file being processed."""

    path: Path
    lines: tuple[str, ...]
    code_blocks: list[CodeBlock]
    syntax: C.MarkerSyntax

    def update(self, verbose: bool, dry_run: bool) -> bool:
        """Update the file's lines based on the current code blocks and optionally show a diff."""
        new_lines = tuple(line for block in self.code_blocks for line in block.lines)
        if self.lines == new_lines:
            if verbose:
                print(f"{C.TERM_CYAN}-----> Unchanged{C.TERM_RESET}")
            return False
        if verbose:
            for line in difflib.unified_diff(self.lines, new_lines, lineterm=""):
                # Skip placeholder headers when fromfile/tofile are unspecified
                if line.startswith("---") or line.startswith("+++"):
                    continue
                if line.startswith("-") and not line.startswith("---"):
                    print(f"{C.TERM_RED}{line}{C.TERM_RESET}")  # Red for removals
                elif line.startswith("+") and not line.startswith("+++"):
                    print(f"{C.TERM_GREEN}{line}{C.TERM_RESET}")  # Green for additions
                elif line.startswith("?"):
                    print(f"{C.TERM_YELLOW}{line}{C.TERM_RESET}")  # Yellow for hints
                else:
                    print(line)
        self.lines = new_lines
        if not dry_run:
            self.path.write_text("\n".join(self.lines) + "\n", encoding="utf-8")
        return True

    @staticmethod
    def from_file(  # noqa: PLR0912
        file: Path, include_empty: bool = False, syntax: C.MarkerSyntax | None = None
    ) -> FileInfo | None:
        """Parse a file to extract code blocks based on stub markers.

        The marker comment syntax is auto-detected from the file extension when
        ``syntax`` is not given.
        """
        assert file.is_file(), f"Expected a file, but got: {file}"
        file = file.resolve()
        if syntax is None:
            syntax = syntax_for(file)
        has_marker = False
        lines: list[str] = file.read_text(encoding="utf-8").splitlines()
        for _, line in enumerate(lines, start=1):
            if line.strip().startswith(syntax.skip_file):
                return None
            if line.strip().startswith(syntax.prefix):
                has_marker = True
        if not has_marker and not include_empty:
            return None
        del has_marker

        codes: list[CodeBlock] = []
        code: CodeBlock | None = None
        for lineno, line in enumerate(lines, 1):
            clean_line = line.strip()
            if clean_line.startswith(syntax.begin):
                # Process "<comment> tvm-ffi-stubgen(begin)"
                if code is not None:
                    raise ValueError(f"Nested stub not permitted at line {lineno}")
                code = CodeBlock.from_begin_line(lineno, clean_line, syntax)
                code.lineno_start = lineno
                code.lines.append(line)
            elif clean_line.startswith(syntax.end):
                # Process "<comment> tvm-ffi-stubgen(end)"
                if code is None:
                    raise ValueError(f"Unmatched `{syntax.end}` found at line {lineno}")
                code.lineno_end = lineno
                code.lines.append(line)
                codes.append(code)
                code = None
            elif clean_line.startswith(syntax.prefix):
                # Process a one-line directive "<comment> tvm-ffi-stubgen(<name>): ..."
                dir_code = CodeBlock.from_begin_line(lineno, clean_line, syntax)
                dir_code.lineno_end = lineno
                dir_code.lines.append(line)
                codes.append(dir_code)
                del dir_code
            elif code is None:
                # Process a plain line outside of any stub block
                codes.append(
                    CodeBlock(
                        kind=None,
                        param="",
                        lineno_start=lineno,
                        lineno_end=lineno,
                        lines=[line],
                    )
                )
            else:  # Process a line inside a stub block
                code.lines.append(line)
        if code is not None:
            raise ValueError("Unclosed stub block at end of file")
        return FileInfo(path=file, lines=tuple(lines), code_blocks=codes, syntax=syntax)

    def reload(self) -> None:
        """Reload the code blocks from disk while preserving original `lines`."""
        source = FileInfo.from_file(self.path, syntax=self.syntax)
        assert source is not None, f"File no longer exists or valid: {self.path}"
        self.code_blocks = source.code_blocks


def collect_files(paths: list[Path], source_exts: Collection[str]) -> list[FileInfo]:
    """Collect all files from the given paths and parse them into FileInfo objects.

    A path given explicitly is always visited; a directory is walked recursively
    and only files whose (lower-cased) extension is in ``source_exts`` -- the
    extensions the active generator owns -- are considered.
    """
    exts = {ext.lower() for ext in source_exts}

    def _on_error(e: Exception) -> None:
        print(
            f"{C.TERM_RED}[Error]\n{traceback.format_exc()}{C.TERM_RESET}",
            end="",
            flush=True,
        )

    def _walk_recursive() -> Generator[Path, None, None]:
        for p in paths:
            if p.is_file():
                yield p
                continue
            for root, _dirs, files in path_walk(p, follow_symlinks=False, on_error=_on_error):
                for file in files:
                    f = Path(root) / file
                    if f.suffix.lower() not in exts:
                        continue
                    yield f

    def _path_sort_key(path: Path) -> str:
        return str(path)

    filenames = list(_walk_recursive())
    filenames = sorted(filenames, key=_path_sort_key)
    files = []
    for file in filenames:
        try:
            content = FileInfo.from_file(file)
        except Exception as e:
            _on_error(e)
        else:
            if content is not None:
                files.append(content)
    return files


def path_walk(
    p: Path,
    *,
    top_down: bool = True,
    on_error: Callable[[Exception], None] | None = None,
    follow_symlinks: bool = False,
) -> Iterable[tuple[Path, list[str], list[str]]]:
    """Compat wrapper for Path.walk (3.12+) with a fallback for < 3.12."""
    if not p.exists():
        return
    # Python 3.12+ - just delegate to `Path.walk`
    if hasattr(p, "walk"):
        yield from p.walk(  # ty: ignore[call-non-callable]
            top_down=top_down,
            on_error=on_error,
            follow_symlinks=follow_symlinks,
        )
        return
    # Python < 3.12 - use `os.walk``
    for root_str, dirnames, filenames in os.walk(
        p,
        topdown=top_down,
        onerror=on_error,
        followlinks=follow_symlinks,
    ):
        root = Path(root_str)
        # dirnames and filenames are lists of *names*, not full paths,
        # just like Path.walk()'s documented behavior.
        yield root, dirnames, filenames
